// data.js
module.exports = {
    host: 'localhost',
    user: 'jh',
    password: 'qwerty',
    database: 'tw1project'
};
