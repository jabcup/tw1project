class Noticia
	attr_accessor :fecha
	attr_accessor :titulo
	attr_accessor :nota
	attr_accessor :fuente
end